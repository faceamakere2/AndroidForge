# HaxBall Client (Android WebView)

## Build a debug APK
1. Install Android Studio (stable) on a computer and allow it to install Android SDK Platform 35 and Android Gradle Plugin dependencies.
2. Open this folder (`HaxBallClient`) in Android Studio.
3. Wait for Gradle Sync to finish.
4. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Android Studio creates `app/build/outputs/apk/debug/app-debug.apk`. This is a debug-signed APK, installable on Android with permission to install unknown apps enabled.

CLI equivalent on a machine with Gradle installed:
`gradle assembleDebug`

## Included
- Landscape sensor orientation, immersive fullscreen, keep-screen-on, hardware accelerated WebView.
- JavaScript + DOM storage.
- Tries to request the highest refresh-rate display mode supported by the current device.
- WebView back navigation.
- HaxBall page + injected settings panel, localStorage settings, FPS counter, animation toggle, scale override, native immersive toggle.

## Important technical limitations
- This project source is provided, but no APK is claimed as built or tested in this environment.
- Android/WebView and the device compositor determine actual display refresh rate. Requesting a high refresh mode cannot make a 60 Hz screen run at 120/144 Hz.
- `requestAnimationFrame` wrapping can influence callbacks in the page's own JS context. A cross-origin game iframe is protected by browser same-origin policy, so page JavaScript cannot reliably patch its `requestAnimationFrame`; the script only attempts same-origin frames. HaxBall/game updates, server tick rate, WebView throttling and display refresh may still limit perceived FPS.
- The `devicePixelRatio` override is best-effort and may not change every canvas/backing-store implementation.
- The panel is injected after `onPageFinished`; if the site replaces its document or navigates internally, injection may need to be repeated.
