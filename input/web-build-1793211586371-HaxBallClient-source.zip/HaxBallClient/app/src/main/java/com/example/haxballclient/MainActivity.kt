package com.example.haxballclient

import android.app.Activity
import android.os.Build
import android.os.Bundle
import android.view.View
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.view.Display
import android.content.Context

class MainActivity : Activity() {
    private lateinit var web: WebView

    @Suppress("DEPRECATION")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_NOTHING)
        applyImmersive(true)
        chooseHighestRefreshRate()

        web = WebView(this)
        web.setBackgroundColor(0xFF101820.toInt())
        web.setLayerType(View.LAYER_TYPE_HARDWARE, null)
        web.webChromeClient = WebChromeClient()
        web.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                view?.evaluateJavascript(PERFORMANCE_SCRIPT, null)
            }
        }

        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            mediaPlaybackRequiresUserGesture = false
            loadsImagesAutomatically = true
            cacheMode = WebSettings.LOAD_DEFAULT
            useWideViewPort = true
            loadWithOverviewMode = true
            setSupportZoom(false)
            builtInZoomControls = false
            displayZoomControls = false
        }
        web.addJavascriptInterface(NativeBridge(), "HaxNative")
        setContentView(web)
        if (savedInstanceState != null) web.restoreState(savedInstanceState)
        else web.loadUrl("https://www.haxball.com/play")
    }

    private fun chooseHighestRefreshRate() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            try {
                val display = windowManager.defaultDisplay
                val modes = display.supportedModes
                val best = modes.maxByOrNull { it.refreshRate }
                if (best != null && Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    val lp = window.attributes
                    lp.preferredDisplayModeId = best.modeId
                    lp.preferredRefreshRate = best.refreshRate
                    window.attributes = lp
                }
            } catch (_: Exception) { }
        }
    }

    private fun applyImmersive(enabled: Boolean) {
        if (enabled) {
            @Suppress("DEPRECATION")
            window.decorView.systemUiVisibility = (
                View.SYSTEM_UI_FLAG_FULLSCREEN
                    or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                    or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                    or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                    or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                    or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
            )
        } else {
            @Suppress("DEPRECATION")
            window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LAYOUT_STABLE
        }
    }

    inner class NativeBridge {
        @JavascriptInterface fun setImmersive(enabled: Boolean) {
            runOnUiThread { applyImmersive(enabled) }
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        web.saveState(outState)
        super.onSaveInstanceState(outState)
    }

    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        if (::web.isInitialized && web.canGoBack()) web.goBack() else super.onBackPressed()
    }

    override fun onDestroy() {
        if (::web.isInitialized) {
            web.removeJavascriptInterface("HaxNative")
            web.destroy()
        }
        super.onDestroy()
    }

    private companion object {
        val PERFORMANCE_SCRIPT = """
        (function(){
          if (window.__haxPerfInstalled) return;
          window.__haxPerfInstalled = true;
          const KEY='haxPerfSettingsV1';
          const defaults={fps:'max',scale:1,showFps:true,animations:false,immersive:true};
          let cfg;
          try { cfg=Object.assign({},defaults,JSON.parse(localStorage.getItem(KEY)||'{}')); }
          catch(e){ cfg=Object.assign({},defaults); }
          const save=()=>{try{localStorage.setItem(KEY,JSON.stringify(cfg));}catch(e){}};
          const maxHz=(()=>{let m=60; try{m=Math.max(m,...(window.screen?.getSupportedRefreshRates?.()||[]));}catch(e){} return m;})();
          function capFrame(win){
            try{
              if(win.__haxRafWrapped) return;
              const original=win.requestAnimationFrame.bind(win);
              const cancel=win.cancelAnimationFrame.bind(win);
              let last=0, nextId=1, pending=new Map();
              win.requestAnimationFrame=function(cb){
                const id=nextId++;
                const target=cfg.fps==='max'?0:Number(cfg.fps);
                const interval=target>0?1000/target:0;
                const tick=(ts)=>{
                  if(!pending.has(id)) return;
                  if(!interval || !last || ts-last+0.5>=interval){
                    last=ts; pending.delete(id); cb(ts);
                  } else original(tick);
                };
                pending.set(id,true);
                original(tick);
                return id;
              };
              win.cancelAnimationFrame=function(id){pending.delete(id);cancel(id);};
              win.__haxRafWrapped=true;
            }catch(e){}
          }
          capFrame(window);
          function visitFrames(){
            document.querySelectorAll('iframe').forEach(f=>{
              try { if(f.contentWindow && f.contentWindow.location.origin===location.origin) capFrame(f.contentWindow); } catch(e){}
            });
          }
          const css=document.createElement('style');
          css.textContent='html,body{overscroll-behavior:none} .haxperf-noanim *, .haxperf-noanim *::before,.haxperf-noanim *::after{animation:none!important;transition:none!important;scroll-behavior:auto!important}';
          (document.head||document.documentElement).appendChild(css);
          let dprBase=window.devicePixelRatio||1;
          try{Object.defineProperty(window,'devicePixelRatio',{configurable:true,get:()=>dprBase*cfg.scale});}catch(e){}
          const button=document.createElement('button');
          button.textContent='≡';
          button.setAttribute('aria-label','HaxBall performance settings');
          button.style.cssText='position:fixed;z-index:2147483647;top:8px;right:8px;width:34px;height:30px;border:1px solid #00e5ff88;border-radius:7px;background:#08151ddd;color:#00e5ff;font:22px/24px sans-serif;cursor:pointer;backdrop-filter:blur(12px)';
          const panel=document.createElement('div');
          panel.style.cssText='position:fixed;z-index:2147483646;top:44px;right:8px;width:228px;padding:12px;border:1px solid #00e5ff66;border-radius:10px;background:rgba(5,16,25,.92);color:#e8fbff;font:12px/1.45 system-ui,sans-serif;box-shadow:0 8px 28px #0008;backdrop-filter:blur(16px);display:none;max-height:75vh;overflow:auto';
          panel.innerHTML='<div style="color:#00e5ff;font-size:13px;font-weight:700;margin-bottom:8px">HAXBALL • PERFORMANCE</div>'+
          '<label style="display:block;margin:8px 0">FPS limiti<select id="hp-fps" style="float:right;background:#102632;color:#fff;border:1px solid #31515d;border-radius:4px"><option value="30">30</option><option value="60">60</option><option value="90">90</option><option value="120">120</option><option value="144">144</option><option value="max">Sınırsız / max Hz</option></select></label>'+
          '<label style="display:block;margin:12px 0">Çözünürlük ölçeği <b id="hp-scaleval"></b><input id="hp-scale" type="range" min=".5" max="2" step=".1" style="display:block;width:100%;accent-color:#00e5ff"></label>'+
          '<label style="display:block;margin:8px 0"><input id="hp-showfps" type="checkbox"> Sol üst FPS sayacı</label>'+
          '<label style="display:block;margin:8px 0"><input id="hp-noanim" type="checkbox"> Animasyonları kapat</label>'+
          '<label style="display:block;margin:8px 0"><input id="hp-immersive" type="checkbox"> Tam ekran / immersive</label>'+
          '<div style="margin-top:10px;color:#89aab5;font-size:10px">Not: FPS, cihaz/ekran ve oyun döngüsüyle sınırlıdır.</div>';
          function el(id){return panel.querySelector('#'+id);}
          const fps=document.createElement('div');
          fps.style.cssText='position:fixed;z-index:2147483645;top:8px;left:8px;padding:3px 6px;border:1px solid #00e5ff55;border-radius:5px;background:#06141dcc;color:#00e5ff;font:12px monospace;pointer-events:none;display:none';
          fps.textContent='FPS: --';
          function render(){
            el('hp-fps').value=cfg.fps;el('hp-scale').value=cfg.scale;el('hp-scaleval').textContent=cfg.scale.toFixed(1)+'x';
            el('hp-showfps').checked=cfg.showFps;el('hp-noanim').checked=cfg.animations;el('hp-immersive').checked=cfg.immersive;
            fps.style.display=cfg.showFps?'block':'none';
            document.documentElement.classList.toggle('haxperf-noanim',cfg.animations);
            if(window.HaxNative&&HaxNative.setImmersive) HaxNative.setImmersive(!!cfg.immersive);
          }
          button.onclick=()=>{panel.style.display=panel.style.display==='none'?'block':'none';};
          el('hp-fps').onchange=e=>{cfg.fps=e.target.value;save();render();};
          el('hp-scale').oninput=e=>{cfg.scale=Number(e.target.value);save();render();};
          el('hp-showfps').onchange=e=>{cfg.showFps=e.target.checked;save();render();};
          el('hp-noanim').onchange=e=>{cfg.animations=e.target.checked;save();render();};
          el('hp-immersive').onchange=e=>{cfg.immersive=e.target.checked;save();render();};
          (document.body||document.documentElement).append(button,panel,fps);
          let frames=0, start=performance.now();
          function meter(now){frames++;if(now-start>=500){fps.textContent='FPS: '+Math.round(frames*1000/(now-start));frames=0;start=now;}requestAnimationFrame(meter);}
          render();visitFrames();setInterval(visitFrames,1500);requestAnimationFrame(meter);
        })();
        """.trimIndent()
    }
}
